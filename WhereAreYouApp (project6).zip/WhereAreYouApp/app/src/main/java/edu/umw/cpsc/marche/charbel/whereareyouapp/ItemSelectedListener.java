package edu.umw.cpsc.marche.charbel.whereareyouapp;

public interface ItemSelectedListener {
    void itemSelected(int index);
}
